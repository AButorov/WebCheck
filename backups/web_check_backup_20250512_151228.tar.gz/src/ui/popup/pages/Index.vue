<template>
  <div class="w-96 bg-white">
    <!-- Шапка приложения -->
    <header class="flex justify-between items-center p-4 border-b">
      <h1 class="text-app-title font-bold">{{ t('popup.header.title') }}</h1>
      <button 
        class="bg-primary-bright text-white rounded-full w-8 h-8 flex items-center justify-center shadow-sm hover:brightness-110"
        :title="t('popup.header.addTask')"
        @click="handleAddTask"
      >
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path stroke-linecap="round" stroke-linejoin="round" d="M12 5v14m-7-7h14" />
        </svg>
      </button>
    </header>
    
    <!-- Список задач -->
    <div class="p-4">
      <!-- Индикатор загрузки -->
      <div v-if="tasksStore.loading" class="text-center py-8">
        <div class="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
        <p class="mt-2 text-gray-500">Загрузка задач...</p>
      </div>
      
      <!-- Сообщение об ошибке -->
      <div v-else-if="tasksStore.error" class="text-center py-8">
        <div class="bg-red-50 border border-red-200 text-red-800 rounded-lg p-4">
          <p>{{ tasksStore.error }}</p>
          <button 
            class="mt-2 text-primary hover:underline"
            @click="tasksStore.loadTasks()"
          >
            Попробовать еще раз
          </button>
        </div>
      </div>
      
      <!-- Пустой список задач -->
      <div v-else-if="tasksStore.tasks.length === 0" class="text-center py-8 text-gray-500">
        {{ t('popup.taskList.noTasks') }}
      </div>
      
      <!-- Список задач -->
      <TaskCard 
        v-else
        v-for="task in tasksStore.tasks" 
        :key="task.id" 
        :task="task"
        @update:interval="updateTaskInterval"
        @update:status="updateTaskStatus"
        @view="viewTaskChanges"
        @remove="removeTask"
      />
    </div>
    
    <!-- Футер с информацией о количестве задач -->
    <footer class="p-4 border-t">
      <p class="text-secondary text-center text-gray-500">
        {{ t('popup.taskList.activeCount', { count: tasksStore.activeTaskCount, total: tasksStore.maxTasks }) }}
      </p>
    </footer>
  </div>
</template>

<script setup lang="ts">
import { onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { useRouter } from 'vue-router'
import { useTasksStore } from '~/stores/tasks'
import { sendMessage } from 'webext-bridge/popup'
import { TaskInterval, TaskStatus } from '~/types/task'
import { MessagePayloads } from '~/types/messages'
import TaskCard from '~/components/TaskCard.vue'
import browser from 'webextension-polyfill'

const { t } = useI18n()
const router = useRouter()
const tasksStore = useTasksStore()

onMounted(async () => {
  await tasksStore.loadTasks()
})

async function handleAddTask() {
  // В реальном приложении здесь будет логика для активации селектора элементов
  // и сохранения выбранного элемента.
  // Для MVP мы просто перейдем на страницу создания задачи
  
  // Проверяем лимит задач
  if (tasksStore.taskCount >= tasksStore.maxTasks) {
    alert('Достигнут лимит задач. Пожалуйста, удалите какую-либо задачу перед добавлением новой.')
    return
  }
  
  try {
    // Отправить сообщение в контент-скрипт для активации селектора элементов
    await sendMessage('activate-selector', null, { context: 'content-script', tabId: await getActiveTabId() })
    // Дальнейшая логика будет обрабатываться через события от контент-скрипта
  } catch (error) {
    console.error('Ошибка при активации селектора:', error)
  }
}

async function updateTaskInterval(taskId: string, interval: TaskInterval) {
  await tasksStore.updateTaskInterval(taskId, interval)
}

async function updateTaskStatus(taskId: string, status: TaskStatus) {
  await tasksStore.updateTaskStatus(taskId, status)
}

async function viewTaskChanges(taskId: string) {
  // Переход на страницу просмотра изменений
  router.push(`/view-changes/${taskId}`)
}

async function removeTask(taskId: string) {
  if (confirm('Вы уверены, что хотите удалить эту задачу?')) {
    await tasksStore.removeTask(taskId)
  }
}

// Получить ID активной вкладки
async function getActiveTabId(): Promise<number> {
  try {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true })
    if (tabs && tabs.length > 0 && tabs[0].id) {
      return tabs[0].id
    }
    throw new Error('Не удалось получить ID активной вкладки')
  } catch (error) {
    console.error('Ошибка при получении ID активной вкладки:', error)
    return -1 // Фиктивный ID для случая ошибки
  }
}
</script>
