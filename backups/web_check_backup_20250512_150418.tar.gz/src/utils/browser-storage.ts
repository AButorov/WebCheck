import browser from 'webextension-polyfill'

/**
 * Получает данные из локального хранилища по ключу
 * @param key Ключ для хранилища
 * @param defaultValue Значение по умолчанию, если данные не найдены
 * @returns Промис с данными
 */
export async function getStorageLocal<T>(key: string, defaultValue: T): Promise<T> {
  try {
    const storage = await browser.storage.local.get(key)
    return storage[key] || defaultValue
  } catch (error) {
    console.error('Ошибка при чтении из локального хранилища:', error)
    return defaultValue
  }
}

/**
 * Сохраняет данные в локальное хранилище
 * @param key Ключ для хранилища
 * @param value Значение для сохранения
 * @returns Промис
 */
export async function setStorageLocal<T>(key: string, value: T): Promise<void> {
  try {
    await browser.storage.local.set({ [key]: value })
  } catch (error) {
    console.error('Ошибка при записи в локальное хранилище:', error)
  }
}

/**
 * Получает данные из синхронизированного хранилища по ключу
 * @param key Ключ для хранилища
 * @param defaultValue Значение по умолчанию, если данные не найдены
 * @returns Промис с данными
 */
export async function getStorageSync<T>(key: string, defaultValue: T): Promise<T> {
  try {
    const storage = await browser.storage.sync.get(key)
    return storage[key] || defaultValue
  } catch (error) {
    console.error('Ошибка при чтении из синхронизированного хранилища:', error)
    return defaultValue
  }
}

/**
 * Сохраняет данные в синхронизированное хранилище
 * @param key Ключ для хранилища
 * @param value Значение для сохранения
 * @returns Промис
 */
export async function setStorageSync<T>(key: string, value: T): Promise<void> {
  try {
    await browser.storage.sync.set({ [key]: value })
  } catch (error) {
    console.error('Ошибка при записи в синхронизированное хранилище:', error)
  }
}
