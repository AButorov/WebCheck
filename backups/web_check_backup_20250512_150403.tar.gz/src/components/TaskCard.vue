<template>
  <div 
    :class="[
      'relative rounded-card shadow-sm p-4 mb-4',
      statusClasses[task.status]
    ]"
  >
    <!-- Заголовок и статус -->
    <div class="flex justify-between items-start mb-2">
      <div class="flex-1">
        <h3 class="text-card-title font-bold truncate pr-8">{{ task.title }}</h3>
        <div class="flex items-center mt-1 text-main">
          <img 
            :src="task.faviconUrl || 'src/assets/icons/globe.svg'" 
            alt="Site icon" 
            class="w-4 h-4 mr-2"
          />
          <span class="truncate">{{ displayUrl }}</span>
        </div>
      </div>
      
      <!-- Кнопка удаления -->
      <button 
        class="absolute top-3 right-3 text-red-action hover:bg-gray-100 rounded-full p-1"
        @click="$emit('remove', task.id)"
        :title="t('popup.taskCard.actions.delete')"
      >
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </div>
    
    <!-- Индикатор статуса и интервал -->
    <div class="flex items-center justify-between mt-3">
      <div class="flex items-center">
        <!-- Индикатор статуса (чекбокс) -->
        <button 
          :class="[
            'w-6 h-6 border-2 rounded flex items-center justify-center mr-2',
            statusCheckboxClasses[task.status]
          ]"
          @click="toggleStatus"
          :title="checkboxTitle"
        >
          <svg v-if="task.status !== 'paused'" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
          </svg>
        </button>
        
        <span :class="['text-main', { 'text-gray-500': task.status === 'paused' }]">
          {{ t(`popup.taskCard.statuses.${task.status}`) }}
        </span>
      </div>
      
      <!-- Селектор интервала -->
      <select 
        v-model="selectedInterval" 
        class="text-secondary bg-white border border-gray-300 rounded px-2 py-1"
        :disabled="task.status === 'paused'"
      >
        <option value="15m">15м</option>
        <option value="1h">1ч</option>
        <option value="3h">3ч</option>
        <option value="1d">1д</option>
      </select>
    </div>
    
    <!-- Индикатор времени и кнопка просмотра изменений -->
    <div class="flex items-center justify-between mt-3">
      <!-- Прогресс-бар оставшегося времени -->
      <div class="w-3/4 bg-gray-200 rounded-full h-2 mr-4">
        <div 
          class="h-2 rounded-full"
          :style="{ width: `${remainingTimePercent}%` }"
          :class="progressBarClasses[task.status]"
        ></div>
      </div>
      
      <!-- Кнопка просмотра изменений -->
      <button 
        v-if="task.status === 'changed'"
        class="bg-purple-action text-white rounded p-1"
        @click="$emit('view', task.id)"
        :title="t('popup.taskCard.actions.view')"
      >
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="11" cy="11" r="8" />
          <path d="M21 21l-4.35-4.35" />
        </svg>
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { WebCheckTask, TaskInterval } from '~/types/task'
import { formatTimeRemaining } from '~/utils/date-format'

const { t } = useI18n()

const props = defineProps<{
  task: WebCheckTask
}>()

const emit = defineEmits<{
  (e: 'update:interval', id: string, interval: TaskInterval): void
  (e: 'update:status', id: string, status: 'paused' | 'unchanged'): void
  (e: 'view', id: string): void
  (e: 'remove', id: string): void
}>()

const selectedInterval = ref(props.task.interval)

watch(selectedInterval, (newValue) => {
  emit('update:interval', props.task.id, newValue as TaskInterval)
})

const displayUrl = computed(() => {
  try {
    const url = new URL(props.task.url)
    return url.hostname
  } catch {
    return props.task.url
  }
})

const remainingTimePercent = computed(() => {
  if (props.task.status === 'paused') {
    return 0
  }
  return formatTimeRemaining(props.task.lastCheckedAt, props.task.interval)
})

const statusClasses = {
  changed: 'bg-amber-light border border-amber-border',
  unchanged: 'bg-green-light border border-green-border',
  paused: 'bg-gray-light border border-gray-border'
}

const statusCheckboxClasses = {
  changed: 'border-amber-status text-amber-status',
  unchanged: 'border-green-status text-green-status',
  paused: 'border-gray-status'
}

const progressBarClasses = {
  changed: 'bg-amber-status',
  unchanged: 'bg-green-status',
  paused: 'bg-gray-status'
}

const checkboxTitle = computed(() => {
  if (props.task.status === 'paused') {
    return t('popup.taskCard.actions.resume')
  }
  return t('popup.taskCard.actions.pause')
})

function toggleStatus() {
  const newStatus = props.task.status === 'paused' ? 'unchanged' : 'paused'
  emit('update:status', props.task.id, newStatus)
}
</script>
