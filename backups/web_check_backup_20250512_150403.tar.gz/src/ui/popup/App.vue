<template>
  <router-view />
</template>

<script setup lang="ts">
// App component
</script>
