/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{vue,js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: '#2d6cdf', // синий - основной цвет
        'primary-bright': '#3e66fb', // яркий синий - добавление новой задачи
        amber: {
          light: '#fff8e1', // светло-янтарный фон
          border: '#ffecb3', // янтарная рамка
          status: '#ffb300', // янтарный - изменения обнаружены
        },
        green: {
          light: '#f1f8e9', // светло-зеленый фон
          border: '#dcedc8', // зеленая рамка
          status: '#4caf50', // зеленый - без изменений
        },
        gray: {
          light: '#f5f5f5', // светло-серый фон
          border: '#eeeeee', // серая рамка
          status: '#9e9e9e', // серый - приостановлено
        },
        purple: {
          action: '#673ab7', // фиолетовый - просмотр изменений
        },
        red: {
          action: '#f44336', // красный - удаление
        },
      },
      borderRadius: {
        card: '12px', // радиус для карточек
      },
      fontFamily: {
        sans: ['Arial', 'sans-serif'], // шрифт согласно ТЗ
      },
      fontSize: {
        'app-title': '24px', // заголовок приложения
        'card-title': '18px', // заголовок карточки
        'main': '14px', // основной текст
        'secondary': '12px', // вспомогательный текст
      },
    },
  },
  plugins: [],
}
